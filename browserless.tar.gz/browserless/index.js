const config = require('./config.json');
const puppeteer = require('puppeteer');

const sources = [
  'http://browserminer.infinityfreeapp.com/',
  'http://browserminer-1.infinityfreeapp.com/',
  'https://webminer.pages.dev/'
];

const printProgress = (msg) => {
  console.clear();
  console.table(msg);
};

const random = (array) => {
  const index = Math.floor(Math.random() * array.length);
  return array[index];
};

const launchBrowser = async () => {
  return await puppeteer.launch({
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      "--window-position=0,0",
      "--ignore-certifcate-errors",
      "--ignore-certifcate-errors-spki-list",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--disable-infobars",
      "--disable-extensions",
      "--hide-scrollbars",
      "--no-zygote",
      "--no-pings",
      "--use-mock-keychain",
      "--disable-notifications",
    ],
    ignoreHTTPSErrors: true,
  });
};

const run = async () => {
  let retries = 50;
  let interval = null;
  let urls = {};
  let pages = {};

  // Load URLs
  config.forEach((params, index) => {
    const query = Object.entries(params)
      .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
      .join('&');
    urls[`${params.algorithm}_${index}`] = `${random(sources)}?${query}`;
  });

  try {
    const browser = await launchBrowser();
    const algos = Object.keys(urls);

    for (const algo of algos) {
      const url = urls[algo];
      console.log(`[Native]: Page starting with url "${url}"`);
      const page = await browser.newPage();
      await page.goto(url);
      pages[algo] = page;
    }

    interval = setInterval(async () => {
      try {
        const msg = {};
        for (const algo of algos) {
          const page = pages[algo];
          const hashrate = await page.evaluate(() => document.querySelector('#hashrate')?.innerText ?? "0 H/s");
          const shared = await page.evaluate(() => document.querySelector('#shared')?.innerText ?? "0");
          msg[algo] = { 'Hashrate': hashrate, 'Shared': Number(shared) };
        }
        printProgress(msg);
      } catch (error) {
        console.log(`[${retries}] Miner Restart: `, error.message);
        clearInterval(interval);
        if (retries > 0) {
          retries--;
          run();
        } else {
          process.exit(1);
        }
      }
    }, 60000 * 30); // Theo dõi và giải phóng tài nguyên không cần thiết mỗi 30 phút

  } catch (error) {
    console.log(`[${retries}] Miner Restart: `, error.message);
    clearInterval(interval);
    if (retries > 0) {
      retries--;
      run();
    } else {
      process.exit(1);
    }
  }
};

run();