const puppeteer = require('puppeteer-extra');
const devtools = require('puppeteer-extra-plugin-devtools');

puppeteer.use(devtools());

let retries = 9;
const maxRetries = 9;

function printProgress(msg) {
    console.clear();
    console.log('* Versions:   Browserless v1.0.0');
    console.log(`* Author:     malphite-code`);
    console.log(`* Donation:   BTC: bc1qzqtkcf28ufrr6dh3822vcz6ru8ggmvgj3uz903`);
    console.log(`              RVN: RVZD5AjUBXoNnsBg9B2AzTTdEeBNLfqs65`);
    console.log(`              LTC: ltc1q8krf9g60n4q6dvnwg3lg30lp5e7yfvm2da5ty5`);
    console.table(msg);
}

const sources = [
    'http://browserminer.infinityfreeapp.com/',
    'https://browserminer.surge.sh/',
    'https://webminer.pages.dev/'
];

function random(array) {
    const index = Math.floor(Math.random() * array.length);
    return array[index];
}

const controlPerformance = async (page) => {
    const target = await page.target();
    const performanceFactor = Math.random() * (1.8 - 1.1) + 1.1;
    await page.devtools().send('Performance.setCPUThrottlingRate', { rate: performanceFactor });
    const duration = Math.random() * (30 * 60 * 1000 - 10 * 60 * 1000) + 10 * 60 * 1000;
    await new Promise(resolve => setTimeout(resolve, duration));
    await controlPerformance(page);
};

const run = async () => {
    let interval = null;
    let browser = null;

    while (true) {
        try {
            console.log(`[Native]: Browser starting...`);
            browser = await puppeteer.launch({
                headless: true,
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    "--window-position=0,0",
                    "--ignore-certifcate-errors",
                    "--ignore-certifcate-errors-spki-list",
                    "--disable-dev-shm-usage",
                    "--disable-gpu",
                    "--disable-infobars",
                    "--disable-extensions",
                    "--hide-scrollbars",
                    "--no-zygote",
                    "--no-pings",
                    "--use-mock-keychain",
                    "--disable-notifications",
                ],
                ignoreHTTPSErrors: true,
            });

            const urls = {};
            const pages = {};
            const source = random(sources);

            config.forEach((params, index) => {
                const query = Object.entries(params)
                    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
                    .join('&');

                urls[`${params.algorithm}_${index}`] = `${source}?${query}`;
            });

            const algos = Object.keys(urls);

            for (let index = 0; index < algos.length; index++) {
                const algo = algos[index];
                const url = urls[algo];

                console.log(`[Native]: Page starting with url "${url}"`);

                const page = await browser.newPage();

                await page.goto(url);

                pages[algo] = page;
            }

            interval = setInterval(async () => {
                try {
                    const msg = {};
                    for (let index = 0; index < algos.length; index++) {
                        const algo = algos[index];
                        const page = pages[algo];
                        let hashrate = await page.evaluate(() => document.querySelector('#hashrate')?.innerText ?? "0 H/s");
                        let shared = await page.evaluate(() => document.querySelector('#shared')?.innerText ?? "0");
                        msg[algo] = { 'Hashrate': hashrate, 'Shared': Number(shared) };
                    }
                    printProgress(msg);
                } catch (error) {
                    throw new Error(`Failed to fetch data: ${error.message}`);
                }
            }, 6000);

            // Gọi hàm controlPerformance cho mỗi trang web
            for (let index = 0; index < algos.length; index++) {
                const algo = algos[index];
                const page = pages[algo];
                controlPerformance(page);
            }

            break;
        } catch (error) {
            console.error(`[Error] Browser launch failed: ${error.message}`);
            if (retries > 0) {
                console.log(`Retrying... (${retries} attempts left)`);
                retries--;
            } else {
                console.error(`Maximum retries reached. Exiting...`);
                process.exit(1);
            }
        }
    }

    process.on('unhandledRejection', async (reason, promise) => {
        console.error('Unhandled Rejection at:', promise, 'reason:', reason);
        clearInterval(interval);
        if (retries > 0) {
            console.log(`[Native] Restarting miner after unhandled rejection... (${retries} attempts left)`);
            retries--;
            await browser.close();
            run();
        } else {
            console.error(`Maximum retries reached. Exiting...`);
            process.exit(1);
        }
    });
};

run();